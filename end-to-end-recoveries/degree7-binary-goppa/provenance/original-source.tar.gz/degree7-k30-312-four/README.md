# Four fresh degree-7, k=30 trials with 312 zeros

This fixed cohort tests the same multiplicity rule as the successful pilot on four new binary Goppa codes. The primary outcome is full equivalent-key recovery by both standard routes, independently verified against the original public code. The pilot is excluded from the four-trial statistics.

The public codes are [64,40] binary Goppa codes over GF(64), with a random irreducible quartic and shuffled full support, shortened to [54,30]. Seeds 2026101701 through 2026101704 were fixed before generation. The first twelve retained finite non-unit constraint columns receive multiplicity 5; all other retained points, including infinity, receive 6; the holdout receives 0. Every trial has 312 zeros, 2,035,800 squarefree degree-7 monomials and 2,136,372 explicit constraints. No key is replaced or filtered by its ranks or recovery outcome.

Each run uses the existing practical CUDA/CADO block Wiedemann sampler, standard projection, a 512-bit block, 8,210 sequence terms and 256 polynomials. Solver seed 2026101602 and compressor seed 2026101603 are unchanged. This is not an implementation of the proved uniform sampler.

PLAN.json fixes the experiment; TRIALS.json pins public inputs and seeds. Private generation data remain outside this package. The small vanishing records were computed locally using those generation secrets to certify curve vanishing only; those secrets, curve jets and old kernel polynomials are never solver/recovery inputs. All four trials are retained regardless of that diagnostic. Gradient/quadratic ranks and recovery outcomes are unknown at packaging time.

## Execution

On the H200 host, install the ordinary C/C++/CMake/GMP/FLINT/MPFR/HWLOC and Python dependencies and run the supplied supervisor wrapper, which invokes:

    bash scripts/run_supervised.sh --build --jobs 16 --threads 32 --ram-gb 64

The queue first checks package hashes, builds the frozen sources and runs a mixed-multiplicity GPU fixture through all three phases. It then overlaps at most one CPU generator with one GPU stage for the fixed cohort. Every trial has its own input, checkpoint, timing, resource and result records. Resuming preserves identities and hashes; it does not change seeds. Overlapped stage durations are not isolated wall-time benchmarks.

Core archives contain the holdout polynomials, Hasse tensors through order 2, exact public inputs, logs, verification records and checksums. Large replay caches are excluded by default. Source code and seeds are preserved in the separate source archive. After copying and verifying each archive locally, run the Sage standard branch/continuation checks and both recovery routes using that trial's public inputs. Failures and incomplete runs remain explicit results.

Local preparation evidence is in preparation-evidence/. Run `python3 -B scripts/validate_inputs.py` to validate all four pinned public instances. `scripts/prepare_batch.py` documents generation and intentionally refuses to overwrite existing private audits; ordinary server execution does not regenerate keys.
