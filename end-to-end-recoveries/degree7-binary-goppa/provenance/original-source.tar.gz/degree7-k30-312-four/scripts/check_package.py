#!/usr/bin/env python3
"""Check every file named in the transport package's integrity manifest."""
import hashlib
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
manifest=ROOT/'SHA256SUMS'
count=0
for line in manifest.read_text().splitlines():
    expected,name=line.split('  ',1)
    path=(ROOT/name).resolve()
    if not path.is_relative_to(ROOT):raise ValueError('manifest path escapes package')
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(4<<20),b''):h.update(block)
    if h.hexdigest()!=expected:raise ValueError('checksum mismatch: '+name)
    count+=1
print(f'Package integrity passed: {count} files.')
