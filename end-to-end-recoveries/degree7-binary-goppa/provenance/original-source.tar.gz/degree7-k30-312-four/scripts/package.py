#!/usr/bin/env python3
"""Freeze sources and four public inputs using an explicit transport allowlist."""
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT.parent / 'degree7-k30-312-four-h200.tar.gz'


def main():
    files = [ROOT/name for name in ['README.md','Makefile','SOURCE-PROVENANCE.json',
                                  'PREPARATION.json','PLAN.json','TRIALS.json']]
    directories = [ROOT/name for name in ['scripts','recovery','holdout','vendor','tests','preparation-evidence']]
    directories += [ROOT/'trials'/f'trial-{i:02d}'/'inputs' for i in range(1,5)]
    for directory in directories:
        for path in directory.rglob('*'):
            rel=path.relative_to(ROOT)
            if any(x in ['build','__pycache__','.git','.DS_Store'] or x.startswith('build-') for x in rel.parts):
                continue
            if not path.is_file() or path.name.startswith('._') or path.suffix in ['.pyc','.o','.a','.so','.dylib']:
                continue
            if path.is_symlink(): raise ValueError('unexpected symlink: '+str(path))
            if path.name in ['secret.json','equivalent-key.json','retained-support.json'] or path.name.startswith(('deep-jets-','seed-prefix-')):
                raise ValueError('private or recovered data in source package')
            files.append(path)
    files=sorted(set(files),key=lambda p:p.relative_to(ROOT).as_posix())
    manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files)
    (ROOT/'SHA256SUMS').write_text(manifest)
    files.append(ROOT/'SHA256SUMS')
    temporary=DEST.with_suffix('.tmp')
    with tarfile.open(temporary,'w:gz') as tar:
        for path in files:
            tar.add(path,arcname=ROOT.name+'/'+path.relative_to(ROOT).as_posix(),recursive=False)
    temporary.replace(DEST)
    digest=hashlib.sha256(DEST.read_bytes()).hexdigest()
    DEST.with_suffix(DEST.suffix+'.sha256').write_text(digest+'  '+DEST.name+'\n')
    print(json.dumps(dict(archive=str(DEST),bytes=DEST.stat().st_size,sha256=digest,files=len(files),private_data_included=False)))


if __name__=='__main__': main()
