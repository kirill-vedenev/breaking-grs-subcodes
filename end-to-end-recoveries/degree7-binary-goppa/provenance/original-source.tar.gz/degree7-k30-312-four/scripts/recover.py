#!/usr/bin/env python3
"""Run both public recovery routes from the independently verified H200 sample."""
import argparse
import json
import os
from pathlib import Path
import shutil
import sys
import time
from server import ROOT, sha, write, execute, restore


def main():
    if not __debug__:raise RuntimeError('do not use Python -O')
    from sage.all import version
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run',type=Path,required=True)
    ap.add_argument('--output',type=Path,required=True)
    ap.add_argument('--inputs',type=Path,help='public-input directory when replaying on another host')
    ap.add_argument('--threads',type=int,default=4)
    args=ap.parse_args();run=args.run.resolve();out=args.output.resolve();start=time.monotonic()
    if args.threads<1:ap.error('thread count must be positive')
    if out.exists():raise FileExistsError('recovery directory already exists; use a fresh destination')
    summary=json.loads((run/'run-summary.json').read_text())
    inputs=Path(summary['inputs'])
    if args.inputs:inputs=args.inputs.resolve()
    elif not inputs.is_dir():inputs=ROOT/inputs.name
    inputs=inputs.resolve()
    if summary['status']!='kernel_verified':raise ValueError('kernel stage is not verified')
    reconstruction=restore(run/'reconstruction');verification=restore(run/'verification')
    if reconstruction is None or verification is None:raise ValueError('missing stage certificates')
    ident=json.loads((run/'identity.json').read_text())
    for name in ('request.txt','operator.txt','experiment.json'):
        if ident['input_hashes'][name]!=sha(inputs/name):raise ValueError('kernel belongs to different public inputs')
    public=json.loads((inputs/'public.json').read_text());config=json.loads((inputs/'experiment.json').read_text())
    index=json.loads(reconstruction['index'].read_text())
    if index['public_sha256']!=public['public_sha256']:raise ValueError('kernel public digest mismatch')
    out.mkdir(parents=True);common=out/'common';common.mkdir();logs=out/'logs';logs.mkdir()
    shutil.copy2(inputs/'public.json',common/'public.json')
    os.environ['TII_JET_SERIES_LIBRARY']=str(ROOT/'build/libseries.so')
    def sage(script,*argv):
        return execute([sys.executable,ROOT/script,*map(str,argv)],logs/(Path(script).stem+'.log'))
    try:
        sage('recovery/verify_input_encoding.py',reconstruction['kernel'],reconstruction['panel'],common/'encoding-verification.json')
        p=public['parameters'];held=public['heldout'][0]
        execute([ROOT/'build/extract-jets',reconstruction['panel'],reconstruction['monomials'],p['k'],p['degree'],
                 public['heldout_mask'],index['count'],common],logs/'extract-jets.log')
        sage('recovery/check_criterion.py',inputs/'public.json',reconstruction['index'],common)
        sage('recovery/extend_jet.py',inputs/'public.json',reconstruction['panel'],common,
             '--depth',config['direct_jet_depth'],'--threads',args.threads)
    except BaseException as error:
        write(out/'summary.json',dict(status='failed',stage='public_local_jet',error=str(error),
              secret_data_used=False,seconds=time.monotonic()-start))
        raise
    routes={}
    for route in ('minor','direct'):
        dest=out/route;dest.mkdir()
        for name in ('public.json',f'deep-jets-{held}.json'):
            shutil.copy2(common/name,dest/name)
        def call(script,*argv):
            execute([sys.executable,ROOT/script,*map(str,argv)],logs/f'{route}-{Path(script).stem}.log')
        try:
            if route=='minor':
                call('recovery/bootstrap.py',dest,'--position',held,'--depth',config['minor_contact_order'])
                report=json.loads((dest/'bootstrap.json').read_text())
                if report.get('minor',{}).get('rank')!=p['n']-3*p['t']-1:
                    raise ValueError('minor code does not have the predicted full dimension')
                if not report.get('recovered_subfield_code_equals_public_code'):
                    raise ValueError('minor route did not recover the shortened public code')
                call('recovery/prepare_retained.py',dest)
                support=dest/'retained-support.json'
            else:
                call('recovery/extract_support.py',inputs/'public.json',dest)
                support=dest/'direct-support.json'
                if json.loads(support.read_text())['report']['status']!='verified':
                    raise ValueError('direct sections did not recover the shortened public code')
            call('recovery/finish_key.py','--public',inputs/'public.json','--support',support,
                 '--original',inputs/'original-public.json','--output',dest/'full-key')
            call('scripts/verify_key.py',inputs/'original-public.json',dest/'full-key/equivalent-key.json',
                 '--report',dest/'independent-verification.json')
            routes[route]=dict(status='passed',verification=json.loads((dest/'independent-verification.json').read_text()),
                               key=str((dest/'full-key/equivalent-key.json').relative_to(out)))
        except Exception as error:
            routes[route]=dict(status='failed',error=str(error))
            write(dest/'failure.json',routes[route])
    report=dict(status='passed' if all(v['status']=='passed' for v in routes.values()) else 'route_failure',
                public_only=True,secret_data_used=False,sage=str(version()),
                instance_id=public['instance_id'],kernel_sha256=sha(reconstruction['kernel']),
                same_kernel_used_by_both_routes=True,routes=routes,seconds=time.monotonic()-start)
    write(out/'summary.json',report);print(json.dumps(report),flush=True)
    if report['status']!='passed':raise SystemExit(1)


if __name__=='__main__':main()
