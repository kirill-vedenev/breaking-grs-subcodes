#!/usr/bin/env python3
"""Build and run the relaxed H200 experiment with checked, resumable stages."""
import argparse
import hashlib
import json
import os
import platform
from pathlib import Path
import shutil
import subprocess
import sys
import threading
import time

ROOT=Path(__file__).resolve().parents[1]


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(4<<20),b''):h.update(block)
    return h.hexdigest()


def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    temporary=path.with_suffix(path.suffix+'.tmp')
    temporary.write_text(json.dumps(data,indent=2)+'\n')
    temporary.replace(path)


def execute(command,log,*,cwd=ROOT,threads=None,gpu=False):
    log.parent.mkdir(parents=True,exist_ok=True)
    env=os.environ.copy()
    env.update(PYTHONDONTWRITEBYTECODE='1',OMP_DYNAMIC='FALSE',OMP_PLACES='cores',
               OMP_PROC_BIND='spread',OMP_MAX_ACTIVE_LEVELS='1')
    if threads is not None:env['OMP_NUM_THREADS']=str(threads)
    command=list(map(str,command));original=list(command)
    if platform.system()=='Linux' and Path('/usr/bin/time').exists():
        command=['/usr/bin/time','-v','-o',str(log.with_suffix('.resources.txt')),*command]
    stop=threading.Event()
    def monitor():
        with log.with_suffix('.gpu.csv').open('w') as f:
            f.write('timestamp,index,memory.used_MiB,utilization.gpu_percent,temperature.gpu_C,power.draw_W\n')
            while not stop.is_set():
                try:
                    p=subprocess.run(['nvidia-smi','--query-gpu=timestamp,index,memory.used,utilization.gpu,temperature.gpu,power.draw',
                                      '--format=csv,noheader,nounits'],capture_output=True,text=True,timeout=10)
                    f.write(p.stdout);f.flush()
                except (OSError,subprocess.TimeoutExpired):pass
                stop.wait(5)
    observer=None
    if gpu and shutil.which('nvidia-smi'):
        observer=threading.Thread(target=monitor,daemon=True);observer.start()
    start=time.monotonic()
    print(json.dumps(dict(event='stage_started',command=original,log=str(log))),flush=True)
    try:
        with log.open('w') as f:
            completed=subprocess.run(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
        code=completed.returncode
    except BaseException as error:
        write(log.with_suffix('.execution.json'),dict(command=original,error=str(error),
              seconds=time.monotonic()-start))
        raise
    finally:
        stop.set()
        if observer:observer.join(timeout=12)
    record=dict(command=original,returncode=code,seconds=time.monotonic()-start)
    write(log.with_suffix('.execution.json'),record)
    print(json.dumps(dict(event='stage_finished',**record)),flush=True)
    if code:raise RuntimeError(f'command failed ({code}); see {log}')
    return record


def seal(job,artifacts,**metadata):
    values={name:dict(path=str(path.relative_to(job)),bytes=path.stat().st_size,sha256=sha(path))
            for name,path in artifacts.items()}
    record=dict(status='complete',artifacts=values,**metadata)
    write(job/'record.json',record)
    return {name:job/v['path'] for name,v in values.items()}


def restore(job):
    path=job/'record.json'
    if not path.exists():return None
    record=json.loads(path.read_text())
    if record.get('status')!='complete':raise ValueError('invalid checkpoint record')
    result={}
    for name,item in record['artifacts'].items():
        target=(job/item['path']).resolve()
        if not target.is_relative_to(job.resolve()):raise ValueError('checkpoint escapes run directory')
        if target.stat().st_size!=item['bytes'] or sha(target)!=item['sha256']:
            raise ValueError(f'checkpoint content changed: {target}')
        result[name]=target
    return result


def attempt(job):
    job.mkdir(parents=True,exist_ok=True)
    i=1
    while (job/f'attempt-{i}').exists() or (job/f'attempt-{i}.log').exists():i+=1
    return job/f'attempt-{i}'


def identity(inputs,config,chunk):
    paths=[inputs/name for name in ('request.txt','operator.txt','experiment.json')]
    paths += [inputs/name for name in ('public.json','vanishing-record.json') if (inputs/name).exists()]
    paths += [ROOT/'scripts/server.py',ROOT/'scripts/validate_inputs.py']
    if (ROOT/'SHA256SUMS').exists():paths.append(ROOT/'SHA256SUMS')
    paths += [ROOT/'holdout/src/square_cufft_worker.cu',ROOT/'holdout/src/common.hpp',
              ROOT/'holdout/src/residual_cleanup.hpp',
              ROOT/'holdout/third_party/saarinen/holdout_cuda_worker.cu',
              ROOT/'vendor/cado-nfs/linalg/bwc/lingen_qcode_binary.cpp',
              ROOT/'vendor/cado-nfs/linalg/bblas/bpack.cpp']
    return dict(schema='degree7-run-identity-v1',input_hashes={p.name:sha(p) for p in paths},
                config=config,chunk_terms=chunk)


def check_verification(report,config,*,production):
    if not report.get('all_original_orders_verified'):
        raise ValueError('original Hasse constraints were not verified')
    if report.get('independent_rank')!=config['requested_samples'] or report.get('verified_elements')!=config['requested_samples']:
        raise ValueError('verified polynomial count or independence mismatch')
    if production and report.get('heldout_nonzero_values')!=0:
        raise ValueError('relaxed polynomials have nonzero held-out values; recovery is not authorized by this result')
    if production and report.get('instance_id')!=config['instance_id']:
        raise ValueError('verification belongs to a different constraint profile')


def establish(output,inputs,config,chunk,resume):
    expected=identity(inputs,config,chunk)
    if output.exists():
        if not resume:raise FileExistsError('run exists; use --resume with unchanged inputs')
        if json.loads((output/'identity.json').read_text())!=expected:
            raise ValueError('run identity mismatch; inputs, source, seeds or chunk size changed')
    else:
        output.mkdir(parents=True);write(output/'identity.json',expected)
    return expected


def run_pipeline(args,inputs,config):
    output=args.output.resolve();chunk=args.chunk_terms
    phase=getattr(args,'phase','all')
    worker=(ROOT/'holdout/build/square-worker').resolve()
    lingen=args.lingen.resolve() if args.lingen else ROOT/'build/cado/linalg/bwc/lingen_b64'
    verifier=ROOT/'holdout/build/holdout-cpu'
    for binary in (worker,lingen,verifier):
        if not binary.is_file():raise FileNotFoundError(f'build required: {binary}')
    establish(output,inputs,config,chunk,args.resume)
    if phase in ('generator','finish') and not (output/'sequence/record.json').exists():
        raise ValueError('the sequence phase must complete first')
    if phase=='finish' and not (output/'generator/record.json').exists():
        raise ValueError('the generator phase must complete first')
    start=time.monotonic();parts=[];state='-';q=config['sequence_terms']
    bits=config['block_bits'];term_bytes=bits*bits//8
    try:
        for first in range(0,q,chunk):
            last=min(first+chunk,q);job=output/'segments'/f'{first:07d}-{last:07d}'
            ready=restore(job)
            if ready is None:
                dest=attempt(job)
                execution=execute([worker,'segment',inputs/'request.txt',state,last-first,dest,
                         config['fft_batch_words'],config['solver_seed'],config['compressor_seed']],
                        dest.with_suffix('.log'),gpu=True)
                result=json.loads((dest/'result.json').read_text())
                assert result['start_step']==first and result['end_step']==last
                assert result['columns']==config['N'] and result['rows']==config['J']
                assert result['block_bits']==bits and result['term_count']==last-first
                assert result['seed_y']==config['solver_seed'] and result['compressor_seed']==config['compressor_seed']
                assert (dest/'sequence.raw.bin').stat().st_size==(last-first)*term_bytes
                ready=seal(job,dict(sequence=dest/'sequence.raw.bin',state=dest/'state.bin',result=dest/'result.json'),execution=execution)
            parts.append(ready['sequence']);state=ready['state']
        job=output/'sequence';ready=restore(job)
        if ready is None:
            job.mkdir(exist_ok=True)
            tmp=job/'sequence.raw.bin.tmp'
            with tmp.open('wb') as out:
                for part in parts:
                    with part.open('rb') as f:shutil.copyfileobj(f,out,4<<20)
            assert tmp.stat().st_size==q*term_bytes
            tmp.replace(job/'sequence.raw.bin')
            ready=seal(job,dict(sequence=job/'sequence.raw.bin'),term_count=q,starts_with_S0=True)
        sequence=ready['sequence']
        if phase=='sequence':
            write(output/'run-status.json',dict(status='sequence_complete',full_key_recovery_completed=False))
            return
        job=output/'generator';ready=restore(job)
        if ready is None:
            dest=attempt(job);dest.mkdir()
            record=execute([lingen,'prime=2',f'm={bits}',f'n={bits}',f'afile={sequence}',
                            f'input_length={q}',f'ffile={dest/"square.gen"}','rhs=none',
                            f'thr={args.threads}x1',f'max_ram={args.ram_gb}',
                            'tuning_thresholds=recursive:100000,notiming:1'],
                           dest.with_suffix('.log'),cwd=dest,threads=args.threads)
            if not (dest/'square.gen').is_file():
                raise RuntimeError(f'CADO produced no eligible generator; its exit code alone is not success. See {dest.with_suffix(".log")}')
            assert (dest/'square.gen').stat().st_size>0 and (dest/'square.gen').stat().st_size%term_bytes==0
            ready=seal(job,dict(generator=dest/'square.gen'),execution=record)
        generator=ready['generator']
        if phase=='generator':
            write(output/'run-status.json',dict(status='generator_complete',full_key_recovery_completed=False))
            return
        job=output/'reconstruction';ready=restore(job)
        if ready is None:
            dest=attempt(job)
            execution=execute([worker,'recover',inputs/'request.txt',generator,dest,config['fft_batch_words'],
                     config['solver_seed'],config['compressor_seed'],1,config['requested_samples']],
                    dest.with_suffix('.log'),gpu=True)
            result=json.loads((dest/'recovery-result.json').read_text())
            assert result['exact_kernel'] and result['independent_rank']>=config['requested_samples']
            assert result['columns']==config['N'] and result['rows']==config['J']
            assert result['output_count']==config['requested_samples']
            ready=seal(job,dict(kernel=dest/'kernel.thk1',panel=dest/'polynomials/kernel-panel.u64le',
                               monomials=dest/'polynomials/monomials-colex.u64',
                               index=dest/'polynomials/index.json',result=dest/'recovery-result.json'),execution=execution)
        reconstruction=ready
        job=output/'verification';verified=restore(job)
        if verified is None:
            dest=attempt(job);dest.mkdir()
            execution=execute([verifier,'verify',inputs/'operator.txt',reconstruction['kernel'],dest/'verification.json',
                     '--threads',args.threads],dest.with_suffix('.log'))
            report=json.loads((dest/'verification.json').read_text())
            check_verification(report,config,production=args.command=='run')
            assert report['instance_id']==(inputs/'operator.txt').read_text().split()[2]
            verified=seal(job,dict(verification=dest/'verification.json'),execution=execution)
        check_verification(json.loads(verified['verification'].read_text()),config,production=args.command=='run')
        timings={}
        timings['GPU_sequence']=sum(json.loads(p.read_text())['execution']['seconds']
                                    for p in (output/'segments').glob('*/record.json'))
        for name in ('generator','reconstruction','verification'):
            timings[name]=json.loads((output/name/'record.json').read_text())['execution']['seconds']
        summary=dict(status='kernel_verified',full_key_recovery_completed=False,
                     inputs=str(inputs),original_input_hashes=identity(inputs,config,chunk)['input_hashes'],
                     artifacts={key:str(path.relative_to(output)) for key,path in reconstruction.items()},
                     verification=str(verified['verification'].relative_to(output)),
                     requested_samples=config['requested_samples'],seconds_this_invocation=time.monotonic()-start,
                     successful_stage_seconds=timings,successful_stage_sum_seconds=sum(timings.values()),
                     stage_sum_is_contiguous_wall_time=False,
                     GPU_execution='completed',next_stage='Run scripts/inspect_kernel.py to measure the new gradients; standard recovery remains a separate result')
        write(output/'run-summary.json',summary)
        write(output/'run-status.json',dict(status='kernel_verified',full_key_recovery_completed=False))
        print(json.dumps(summary),flush=True)
    except BaseException as error:
        write(output/'run-status.json',dict(status='failed_or_interrupted',error=str(error),
              seconds_this_invocation=time.monotonic()-start,completed_checkpoints_retained=True))
        raise


def build(args):
    log=ROOT/'build';log.mkdir(exist_ok=True)
    execute(['make','cpu'],log/'native-build.log')
    execute(['make','-C','holdout','gpu',f'CUDA_ARCH={args.cuda_arch}'],log/'cuda-build.log')
    configure=['cmake','-S',ROOT/'vendor/cado-nfs','-B',ROOT/'build/cado',
               '-DCMAKE_BUILD_TYPE=Release','-DWITH_MPI=OFF','-DCMAKE_POLICY_VERSION_MINIMUM=3.5',
               f'-DPYTHON_EXECUTABLE={sys.executable}']
    execute(configure,log/'cado-configure.log')
    execute(['cmake','--build',ROOT/'build/cado','--target','lingen_b64','-j',args.jobs],log/'cado-build.log')


def benchmark(args,inputs,config):
    output=args.output.resolve()
    if output.exists():raise FileExistsError('benchmark output exists')
    output.parent.mkdir(parents=True,exist_ok=True)
    execute([ROOT/'holdout/build/square-worker','segment',inputs/'request.txt','-',args.steps,output,
             config['fft_batch_words'],config['solver_seed'],config['compressor_seed']],
            output.with_suffix('.log'),gpu=True)
    report=json.loads((output/'result.json').read_text())
    numerical=sum(report[name] for name in ('m_seconds_total','compress_seconds_total','projection_seconds_total'))
    forecast=dict(scope='Measured short GPU probe; extrapolated sequence only, not a full-runtime guarantee',
                  measured_steps=args.steps,numerical_seconds=numerical,
                  sequence_hours_estimate=numerical/args.steps*config['sequence_terms']/3600,
                  planned_sequence_terms=config['sequence_terms'],CPU_generator_not_measured=True,
                  full_recovery_not_run=True)
    write(output/'forecast.json',forecast);print(json.dumps(forecast),flush=True)


def preflight(inputs):
    from constraint_profile import profile
    from validate_inputs import validate
    files=['nvcc','nvidia-smi','cmake','make','c++']
    config=json.loads((inputs/'experiment.json').read_text())
    public=json.loads((inputs/'public.json').read_text())
    counts=profile(public)
    for key in ('N','J','nonzeros','forced_zeros','composition_degree_bound'):
        if counts[key]!=config[key]:raise ValueError('constraint count mismatch: '+key)
    if counts['predicted_kernel_dimension']<config['requested_samples']:
        raise ValueError('kernel dimension forecast is below the requested sample count: '+str(counts))
    certificate=validate(inputs)
    # The legacy sliced CSR builder expects each literal row to be present.
    # Point weight >= d makes every retained derivative row nonzero.
    active=[p for p in public['points'] if p['mask'].bit_count()>=2]
    if any(p['mask'].bit_count()<public['parameters']['degree'] for p in active):
        raise ValueError('legacy CUDA CSR requires nonzero literal rows at each active point')
    report=dict(platform=platform.platform(),logical_cpus=os.cpu_count(),
                tools={name:shutil.which(name) for name in files},
                disk_free_GiB=shutil.disk_usage(ROOT).free/2**30,experiment=config,constraint_profile=counts,
                input_validation_passed=True,vanishing_preparation_record=certificate,
                hardware_execution_tested=False)
    if shutil.which('nvidia-smi'):
        p=subprocess.run(['nvidia-smi'],capture_output=True,text=True);report['gpu_inventory']=p.stdout
    path=inputs.parent/'server-preflight.json' if config.get('trial_id') else ROOT/'build'/(inputs.name+'-preflight.json')
    write(path,report)
    print(json.dumps(report,indent=2))


def main():
    if not __debug__:raise RuntimeError('Python optimization disables verification; do not use -O')
    ap=argparse.ArgumentParser(description=__doc__);sub=ap.add_subparsers(dest='command',required=True)
    p=sub.add_parser('preflight');p.add_argument('--inputs',type=Path,default=ROOT/'inputs')
    b=sub.add_parser('build');b.add_argument('--jobs',type=int,default=16);b.add_argument('--cuda-arch',type=int,default=90)
    b=sub.add_parser('benchmark');b.add_argument('--steps',type=int,default=128)
    b.add_argument('--inputs',type=Path,default=ROOT/'inputs')
    b.add_argument('--output',type=Path,default=ROOT/'runs/benchmark')
    for name in ('run','smoke'):
        p=sub.add_parser(name);p.add_argument('--output',type=Path,default=ROOT/'runs'/('roots312' if name=='run' else 'gpu-smoke'))
        p.add_argument('--phase',choices=['all','sequence','generator','finish'],default='all')
        p.add_argument('--threads',type=int,default=32 if name=='run' else 4)
        p.add_argument('--ram-gb',type=int,default=64);p.add_argument('--chunk-terms',type=int,default=1024)
        p.add_argument('--lingen',type=Path);p.add_argument('--resume',action='store_true')
        if name=='run':p.add_argument('--inputs',type=Path,default=ROOT/'inputs')
        if name=='smoke':
            p.add_argument('--wide',action='store_true',help='exercise the production 512-bit block width')
            p.add_argument('--inputs',type=Path,help='explicit software-test fixture')
    args=ap.parse_args()
    for field in ('jobs','steps','threads','ram_gb','chunk_terms'):
        if hasattr(args,field) and getattr(args,field)<1:ap.error(f'{field} must be positive')
    if args.command=='preflight':return preflight(args.inputs.resolve())
    if args.command=='build':return build(args)
    inputs=(args.inputs.resolve() if args.inputs else ROOT/('tests/wide-smoke-inputs' if args.wide else 'tests/smoke-inputs')) if args.command=='smoke' else args.inputs.resolve()
    config=json.loads((inputs/'experiment.json').read_text())
    if args.command=='run':preflight(inputs)
    if args.command=='benchmark':return benchmark(args,inputs,config)
    return run_pipeline(args,inputs,config)


if __name__=='__main__':main()
