#!/usr/bin/env python3
"""Verify the saved encoding and measure local ranks without Sage or a key."""
import argparse
from itertools import combinations
import json
from math import comb
from pathlib import Path
import struct

from validate_inputs import validate
from server import ROOT, attempt, check_verification, execute, restore, seal, sha, write


def reduced(rows):
    pivots = {}
    for value in rows:
        while value:
            pivot = value.bit_length() - 1
            if pivot in pivots:
                value ^= pivots[pivot]
            else:
                pivots[pivot] = value
                break
    for pivot in sorted(pivots):
        for other in pivots:
            if other > pivot and (pivots[other] >> pivot) & 1:
                pivots[other] ^= pivots[pivot]
    return pivots


def rank(rows):
    return len(reduced(rows))


def nullspace(rows, width):
    pivots = reduced(rows)
    answer = []
    for free in range(width):
        if free in pivots:
            continue
        value = 1 << free
        for pivot, row in pivots.items():
            value |= ((row >> free) & 1) << pivot
        answer.append(value)
    return answer


def tensor_rows(path, columns, count):
    words = (count + 63) // 64
    raw = path.read_bytes()
    if len(raw) != columns * words * 8:
        raise ValueError("Taylor tensor has wrong length")
    data = struct.unpack("<" + "Q" * (len(raw) // 8), raw)
    if count % 64 and any(data[c * words + words - 1] >> (count % 64) for c in range(columns)):
        raise ValueError("Taylor tensor padding is nonzero")
    return [sum(((data[c * words + i // 64] >> (i % 64)) & 1) << c for c in range(columns))
            for i in range(count)]


def analyze(public, tensors, count):
    k, m = public["parameters"]["k"], public["parameters"]["m"]
    point = public["heldout_mask"]
    values = tensor_rows(tensors / "hasse-0.u64le", 1, count)
    J = tensor_rows(tensors / "hasse-1.u64le", k, count)
    Q = tensor_rows(tensors / "hasse-2.u64le", comb(k, 2), count)
    if any(values):
        raise ValueError("extracted held-out polynomial values are nonzero")
    if any((row & point).bit_count() % 2 for row in J):
        raise ValueError("Euler identity failed at the held-out point")
    basis = [point]
    for row in nullspace(J, k):
        if rank(basis + [row]) > len(basis):
            basis.append(row)
    quotient = basis[1:]
    pairs = sorted(combinations(range(k), 2), key=lambda p: (1 << p[0]) + (1 << p[1]))

    def pair_values(v):
        return sum((((v >> a) & 1) & ((v >> b) & 1)) << i for i, (a, b) in enumerate(pairs))

    monomials = []
    for i, u in enumerate(quotient):
        for j in range(i, len(quotient)):
            v = quotient[j]
            monomials.append(pair_values(u) if i == j else pair_values(u ^ v) ^ pair_values(u) ^ pair_values(v))
    restricted = [sum(((row & monomial).bit_count() % 2) << i for i, monomial in enumerate(monomials)) for row in Q]
    transpose = [sum(((row >> j) & 1) << i for i, row in enumerate(J)) for j in range(k)]
    stationary = []
    for combination in nullspace(transpose, count):
        row = 0
        while combination:
            bit = combination & -combination
            row ^= restricted[bit.bit_length() - 1]
            combination ^= bit
        stationary.append(row)
    expected_gradient = k - m - 1
    expected_quadratic = comb(m, 2)
    jr, qr, sr = rank(J), rank(restricted), rank(stationary)
    return dict(status="measured", public_only=True, recovered_key_or_jet_used=False,
                kernel_polynomials=count, gradient_filter_applied=False, heldout_nonzero_values=0,
                gradient_rank=jr, expected_gradient_rank=expected_gradient,
                gradient_annihilator_dimension=k-jr, quotient_dimension=len(quotient),
                zero_gradient_sample_count=sum(row == 0 for row in J),
                stationary_polynomial_dimension=count-jr, restricted_quadratic_rank=qr,
                restricted_stationary_quadratic_rank=sr, expected_restricted_quadratic_rank=expected_quadratic,
                standard_binary_rank_criterion_holds=jr == expected_gradient and qr == expected_quadratic,
                standard_stationary_rank_criterion_holds=jr == expected_gradient and sr == expected_quadratic,
                gradient_prefix_ranks={str(n):rank(J[:n]) for n in [16, 32, 64, 128, count] if n <= count},
                branch_separation_tested=False, continuation_tested=False, key_recovery_completed=False)


def verify_encoding(kernel, panel, k, d, count):
    import numpy as np
    with kernel.open("rb") as f:
        header = f.read(20)
    N = comb(k, d)
    if header[:4] != b"THK1" or struct.unpack("<4I", header[4:]) != (k, d, N, count):
        raise ValueError("kernel header mismatch")
    stride = (N + 7) // 8
    if kernel.stat().st_size != 20 + count * stride or panel.stat().st_size % (N * 8):
        raise ValueError("kernel or panel length mismatch")
    panel_bytes = panel.stat().st_size // N
    if panel_bytes * 8 < count:
        raise ValueError("panel too narrow")
    packed = np.memmap(kernel, dtype=np.uint8, mode="r", offset=20, shape=(count, stride))
    actual = np.memmap(panel, dtype=np.uint8, mode="r", shape=(N, panel_bytes))
    for start in range(0, N, 32768):
        end = min(N, start + 32768)
        bits = np.unpackbits(np.ascontiguousarray(packed[:, start // 8:(end + 7) // 8]), axis=1, bitorder="little")[:, :end-start].transpose()
        raw = np.packbits(bits, axis=1, bitorder="little")
        if not np.array_equal(actual[start:end, :raw.shape[1]], raw) or np.any(actual[start:end, raw.shape[1]:]):
            raise ValueError("THK1 and panel coefficients differ")
    if N % 8 and np.any(packed[:, -1] >> (N % 8)):
        raise ValueError("kernel padding is nonzero")
    return dict(status="passed", all_coefficient_bits_compared=N*count, nonzero_unused_panel_columns=False)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run", type=Path, default=ROOT / "runs/roots312")
    ap.add_argument("--inputs", type=Path, default=ROOT / "inputs")
    args = ap.parse_args(); run = args.run.resolve(); inputs = args.inputs.resolve()
    validate(inputs)
    config = json.loads((inputs / "experiment.json").read_text())
    public = json.loads((inputs / "public.json").read_text())
    identity = json.loads((run / "identity.json").read_text())
    for name in ["request.txt", "operator.txt", "experiment.json", "public.json", "vanishing-record.json"]:
        if identity["input_hashes"][name] != sha(inputs / name):
            raise ValueError("run belongs to different inputs")
    reconstruction = restore(run / "reconstruction")
    verified = restore(run / "verification")
    if reconstruction is None or verified is None:
        raise ValueError("a verified kernel is required")
    check_verification(json.loads(verified["verification"].read_text()), config, production=True)
    job = run / "inspection"
    ready = restore(job)
    if ready is None:
        dest = attempt(job); dest.mkdir()
        p = public["parameters"]; count = config["requested_samples"]
        encoding = verify_encoding(reconstruction["kernel"], reconstruction["panel"], p["k"], p["degree"], count)
        index = json.loads(reconstruction["index"].read_text())
        if index["public_sha256"] != public["public_sha256"] or index["count"] != count:
            raise ValueError("reconstruction index mismatch")
        execute([ROOT / "build/extract-jets", reconstruction["panel"], reconstruction["monomials"],
                 p["k"], p["degree"], public["heldout_mask"], count, dest / "tensors"], dest / "extract.log")
        report = analyze(public, dest / "tensors", count)
        report.update(instance_id=public["instance_id"], fixed_cohort_trial=config["trial_id"],
                      kernel_sha256=sha(reconstruction["kernel"]), input_sha256=sha(inputs / "public.json"),
                      encoding=encoding, samples_selected_by_geometry=False)
        write(dest / "inspection.json", report)
        ready = seal(job, dict(report=dest / "inspection.json", **{f"hasse_{u}":dest / "tensors" / f"hasse-{u}.u64le" for u in range(p["degree"])}))
    print(ready["report"].read_text(), flush=True)


if __name__ == "__main__":
    main()
