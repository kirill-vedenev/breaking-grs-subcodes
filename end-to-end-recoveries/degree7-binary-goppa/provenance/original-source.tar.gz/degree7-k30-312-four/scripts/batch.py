"""Run the fixed cohort with one GPU task and at most one CPU generator at once."""
from concurrent.futures import ThreadPoolExecutor, wait, FIRST_COMPLETED
from pathlib import Path
import argparse
import json
import subprocess
import sys
import time

from server import ROOT, write
from validate_inputs import validate


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--build',action='store_true')
    parser.add_argument('--threads',type=int,default=32)
    parser.add_argument('--ram-gb',type=int,default=64)
    parser.add_argument('--jobs',type=int,default=16)
    args=parser.parse_args()
    if min(args.threads,args.ram_gb,args.jobs)<1: parser.error('resources must be positive')
    registry=json.loads((ROOT/'TRIALS.json').read_text())
    subprocess.run([sys.executable,'-B',ROOT/'scripts/check_package.py'],check=True,cwd=ROOT)
    for trial in registry['trials']:
        if trial['status']=='prepared': validate(ROOT/trial['inputs'])
    if args.build:
        subprocess.run([sys.executable,'-B',ROOT/'scripts/server.py','build','--jobs',str(args.jobs)],check=True,cwd=ROOT)
    # Actual GPU regression for the newly split phases before production.
    smoke=ROOT/'runs/gpu-smoke-phased'
    for phase in ['sequence','generator','finish']:
        subprocess.run([sys.executable,'-B',ROOT/'scripts/server.py','smoke','--phase',phase,
                        '--inputs',ROOT/'tests/mixed-smoke-inputs','--output',smoke,'--resume',
                        '--threads','4','--ram-gb',str(args.ram_gb)],check=True,cwd=ROOT)
    state_path=ROOT/'BATCH-STATE.json'
    previous=json.loads(state_path.read_text()) if state_path.exists() else {}
    outcomes=previous.get('outcomes',{})
    start=time.monotonic()
    def save():
        write(state_path,dict(status='running' if len(outcomes)<len(registry['trials']) else 'kernel_batch_complete',
                              primary_trial_count=4,prior_pilot_excluded=True,outcomes=outcomes,
                              fixed_key_seeds=[t['key_seed'] for t in registry['trials']],
                              CPU_generator_can_overlap_other_trials_GPU=True,
                              maximum_simultaneous_GPU_stages=1,maximum_simultaneous_CPU_generators=1,
                              seconds_this_invocation=time.monotonic()-start))
    def invoke(trial,phase):
        dest=ROOT/'trials'/trial['trial_id'];run=dest/'run';logs=dest/'driver-logs';logs.mkdir(exist_ok=True)
        command=[sys.executable,'-B','-u',ROOT/'scripts/server.py','run','--phase',phase,
                 '--inputs',ROOT/trial['inputs'],'--output',run,'--resume',
                 '--threads',str(args.threads),'--ram-gb',str(args.ram_gb)]
        print(json.dumps(dict(event='batch_phase_started',trial_id=trial['trial_id'],phase=phase)),flush=True)
        with (logs/(phase+'.log')).open('a') as stream:
            result=subprocess.run(list(map(str,command)),cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
        print(json.dumps(dict(event='batch_phase_finished',trial_id=trial['trial_id'],phase=phase,returncode=result.returncode)),flush=True)
        return result.returncode
    def collect(trial):
        dest=ROOT/'trials'/trial['trial_id'];run=dest/'run'
        command=[sys.executable,'-B',ROOT/'scripts/collect_results.py','--run',run,'--inputs',ROOT/trial['inputs']]
        with (dest/'driver-logs/collect.log').open('a') as stream:
            result=subprocess.run(list(map(str,command)),cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
        if result.returncode: raise RuntimeError('Artifact collection failed for '+trial['trial_id'])
        return json.loads((dest/'RESULTS.json').read_text())
    pending=[]
    for trial in registry['trials']:
        label=trial['trial_id']
        if label in outcomes: continue
        if trial['status']!='prepared': outcomes[label]=trial;save();continue
        pending.append(trial)
    futures={}
    save()
    with ThreadPoolExecutor(max_workers=1) as pool:
        while pending or futures:
            ready=[future for future in futures if future.done()]
            if ready:
                future=ready[0];trial=futures.pop(future);label=trial['trial_id']
                code=future.result()
                if not code:
                    code=invoke(trial,'finish')
                    if not code:
                        dest=ROOT/'trials'/label
                        with (dest/'driver-logs/inspection.log').open('a') as stream:
                            process=subprocess.run([sys.executable,'-B',ROOT/'scripts/inspect_kernel.py',
                                                    '--run',dest/'run','--inputs',ROOT/trial['inputs']],
                                                   cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
                        code=process.returncode
                result=collect(trial)
                outcomes[label]=dict(status=result['status'],returncode=code,
                                     key_seed=trial['key_seed'],instance_id=trial['instance_id'],
                                     gradient_rank=result.get('gradient_rank'),
                                     quadratic_rank=result.get('inspection',{}).get('restricted_quadratic_rank'))
                save()
            elif pending:
                trial=pending.pop(0)
                code=invoke(trial,'sequence')
                if code:
                    result=collect(trial)
                    outcomes[trial['trial_id']]=dict(status='sequence_failed',returncode=code,
                                                   key_seed=trial['key_seed'],instance_id=trial['instance_id'])
                    save()
                else:
                    futures[pool.submit(invoke,trial,'generator')]=trial
            else:
                wait(list(futures),timeout=30,return_when=FIRST_COMPLETED)
    save()
    print(json.dumps(dict(event='batch_finished',outcomes=outcomes)),flush=True)


if __name__=='__main__': main()
