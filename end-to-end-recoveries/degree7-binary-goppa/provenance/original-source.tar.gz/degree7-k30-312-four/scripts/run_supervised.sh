#!/usr/bin/env bash
set -euo pipefail
task_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$task_root"
mkdir -p runs
python3 -B -u scripts/batch.py "$@" 2>&1 | tee -a runs/launcher.log
