#!/usr/bin/env python3
"""Collect verified kernels or failure evidence before a server is shut down."""
import argparse
import json
from pathlib import Path
import tarfile

from server import ROOT, check_verification, restore, sha, write


def archive(selected, target, description):
    selected = sorted(set(selected))
    for p in selected:
        if p.is_symlink() or not p.resolve().is_relative_to(ROOT):
            raise ValueError("archive path is not a regular package file: " + str(p))
    inventory = target.with_suffix(".inventory.json")
    write(inventory, dict(description=description,
                         files={str(p.relative_to(ROOT)):dict(bytes=p.stat().st_size, sha256=sha(p)) for p in selected}))
    temporary = target.with_suffix(".tmp")
    with tarfile.open(temporary, "w:gz", compresslevel=1) as tar:
        for p in selected + [inventory]:
            tar.add(p, arcname=p.relative_to(ROOT).as_posix(), recursive=False)
    temporary.replace(target)
    digest = sha(target)
    target.with_suffix(target.suffix + ".sha256").write_text(digest + "  " + target.name + "\n")
    return dict(path=str(target.relative_to(ROOT)), bytes=target.stat().st_size, sha256=digest)


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--run", type=Path, required=True)
    ap.add_argument("--inputs", type=Path, required=True)
    ap.add_argument("--replay", action="store_true")
    args = ap.parse_args(); run = args.run.resolve()
    if not run.is_relative_to(ROOT):
        raise ValueError("run must be inside this experiment directory")
    inputs=args.inputs.resolve()
    if not inputs.is_relative_to(ROOT): raise ValueError('inputs must be inside the batch directory')
    config = json.loads((inputs / "experiment.json").read_text())
    trial_id=config['trial_id']
    reconstruction = restore(run / "reconstruction")
    verification = restore(run / "verification")
    inspection = restore(run / "inspection")
    standard = restore(run / "standard-checks")
    status = dict(status="incomplete", key_recovery_completed=False, instance_id=config["instance_id"],
                  trial_id=trial_id,key_seed=config['seed'],
                  parameter_choice_uses_prior_recovery_diagnosis=True,
                  prior_recovered_key_or_jet_used_in_search=False,
                  requested_polynomials=config["requested_samples"], forced_zeros=config["forced_zeros"],
                  solver=config["solver"], gradient_rank=None)
    if verification is not None:
        certificate = json.loads(verification["verification"].read_text())
        check_verification(certificate, config, production=True)
        status.update(status="kernel_verified", verification=certificate)
    if inspection is not None:
        if verification is None:
            raise ValueError('inspection exists without a verified kernel')
        local = json.loads(inspection["report"].read_text())
        status.update(status="kernel_verified_and_ranks_measured", gradient_rank=local["gradient_rank"],
                      standard_binary_rank_criterion_holds=local["standard_binary_rank_criterion_holds"],
                      inspection=local)
    if standard is not None:
        checks = json.loads(standard['report'].read_text())
        status['standard_checks'] = checks
        status['standard_recovery_criteria_passed'] = checks['status'] == 'passed'
    else:
        status['standard_checks'] = {'status': 'pending_Sage_checks'}
        status['standard_recovery_criteria_passed'] = None
    if verification is None:
        candidates=sorted((run/'verification').glob('attempt-*/verification.json'))
        if candidates:
            raw=json.loads(candidates[-1].read_text())
            status['unsealed_verification']=raw
            try:
                check_verification(raw,config,production=True)
                status['status']='verification_unsealed'
            except ValueError as error:
                status['status']='verification_failed'
                status['verification_error']=str(error)
        if (run/'run-status.json').exists(): status['run_status']=json.loads((run/'run-status.json').read_text())
    result_path=run.parent/'RESULTS.json'
    write(result_path, status)
    selected = {result_path, ROOT / "SOURCE-PROVENANCE.json", ROOT/'PLAN.json', ROOT/'TRIALS.json'}
    selected.update(ROOT / name for name in ['PREPARATION.json', 'SHA256SUMS', 'README.md'] if (ROOT / name).is_file())
    selected.update(p for p in inputs.glob('*') if p.is_file())
    for directory in [run, ROOT / "build"]:
        for p in directory.rglob("*"):
            if p.is_file() and (p.suffix in [".json", ".log", ".csv"] or p.name.endswith(".resources.txt")):
                if "sage-cache" in p.relative_to(directory).parts:
                    continue
                if directory == ROOT / "build" and "cado" in p.relative_to(directory).parts:
                    continue
                selected.add(p)
    if reconstruction:
        selected.add(reconstruction["kernel"])
    if inspection:
        selected.update(inspection[f"hasse_{u}"] for u in range(3))
    artifacts = ROOT / "artifacts"; artifacts.mkdir(exist_ok=True)
    results = [archive(selected, artifacts / f"degree7-k30-312-four-{trial_id}-results.tar.gz",
                       "Inputs, kernel, certificates, local ranks, and logs. Panel/map can be rebuilt from THK1 with scripts/materialize_panel.py; higher Taylor tensors can be recomputed.")]
    if args.replay:
        replay = set()
        for name, artifact in [("sequence", "sequence"), ("generator", "generator")]:
            ready = restore(run / name)
            if ready:
                replay.add(ready[artifact]); replay.add(run / name / "record.json")
        segments = sorted((run / "segments").glob("*/record.json"))
        if segments:
            ready = restore(segments[-1].parent)
            replay.add(ready["state"]); replay.add(segments[-1])
        for p in [ROOT / "holdout/build/square-worker", ROOT / "holdout/build/holdout-cpu",
                  ROOT / "build/cado/linalg/bwc/lingen_b64", ROOT / "build/extract-jets", ROOT / "build/libseries.so"]:
            if p.exists():
                replay.add(p)
        if replay:
            results.append(archive(replay, artifacts / "degree7-k30-312-replay.tar.gz",
                                   "Companion to the result archive: available sequence, generator, last sealed Krylov state, and runtime binaries."))
    write(artifacts / f"{trial_id}-download-manifest.json", dict(status=status["status"],trial_id=trial_id, archives=results,
                                                     copy_before_server_shutdown=True,
                                                     replay_included=bool(args.replay), replay_required=False,
                                                     source_archive='degree7-k30-312-four-h200.tar.gz'))
    print(json.dumps(dict(status=status["status"], gradient_rank=status["gradient_rank"], archives=results)), flush=True)


if __name__ == "__main__":
    main()
