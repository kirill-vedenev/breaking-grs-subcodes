#!/usr/bin/env python3
"""Rebuild the redundant panel/map from THK1 and verify the server's hashes."""
import argparse
from array import array
import json
from math import comb
from pathlib import Path
import struct
import sys
import numpy as np
from server import sha


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--run',type=Path,required=True)
    args=ap.parse_args();job=(args.run/'reconstruction').resolve()
    record=json.loads((job/'record.json').read_text())['artifacts']
    def target(name):
        path=(job/record[name]['path']).resolve()
        if not path.is_relative_to(job):raise ValueError('artifact escapes run directory')
        return path
    kernel=target('kernel')
    if sha(kernel)!=record['kernel']['sha256']:raise ValueError('kernel digest mismatch')
    with kernel.open('rb') as f:header=f.read(20)
    if header[:4]!=b'THK1':raise ValueError('expected colex THK1')
    k,d,N,count=struct.unpack('<4I',header[4:])
    if N!=comb(k,d):raise ValueError('monomial count mismatch')
    stride=(N+7)//8
    if kernel.stat().st_size!=20+count*stride:raise ValueError('kernel length mismatch')
    rebuilt=[]
    for name in ('panel','monomials'):
        path=target(name)
        if path.exists():
            if sha(path)!=record[name]['sha256']:raise ValueError('existing artifact differs: '+name)
            continue
        path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix(path.suffix+'.tmp')
        if name=='panel':
            total=record[name]['bytes']
            if total%(N*8):raise ValueError('invalid expected panel size')
            words=total//(N*8)
            if words*64<count:raise ValueError('insufficient expected panel width')
            packed=np.memmap(kernel,dtype=np.uint8,mode='r',offset=20,shape=(count,stride))
            with tmp.open('wb') as out:
                for start in range(0,N,32768):
                    end=min(N,start+32768)
                    bits=np.unpackbits(np.ascontiguousarray(packed[:,start//8:(end+7)//8]),
                                       axis=1,bitorder='little')[:,:end-start].transpose()
                    raw=np.packbits(bits,axis=1,bitorder='little')
                    padded=np.zeros((end-start,words*8),dtype=np.uint8)
                    padded[:,:raw.shape[1]]=raw;out.write(padded.tobytes())
        else:
            value=(1<<d)-1;block=array('Q')
            with tmp.open('wb') as out:
                for i in range(N):
                    block.append(value)
                    low=value&-value;next_value=value+low
                    value=next_value|(((next_value^value)>>2)//low)
                    if len(block)==32768 or i+1==N:
                        if sys.byteorder!='little':block.byteswap()
                        block.tofile(out);block=array('Q')
        if tmp.stat().st_size!=record[name]['bytes'] or sha(tmp)!=record[name]['sha256']:
            raise ValueError('reconstructed artifact differs from server certificate: '+name)
        tmp.replace(path);rebuilt.append(name)
    print(json.dumps(dict(status='passed',rebuilt=rebuilt,server_hashes_matched=True)))


if __name__=='__main__':main()
