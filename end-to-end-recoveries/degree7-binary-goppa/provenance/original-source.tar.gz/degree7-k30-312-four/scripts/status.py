#!/usr/bin/env python3
"""Compact read-only progress for the H200 experiment."""
import argparse
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def last_json(path):
    if not path.exists():return None
    with path.open('rb') as f:
        f.seek(max(0,path.stat().st_size-16384));text=f.read().decode(errors='replace')
    for line in reversed(text.splitlines()):
        if line.startswith('{'):
            try:return json.loads(line)
            except json.JSONDecodeError:pass
    return None


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--run',type=Path,default=ROOT/'runs/roots312');args=ap.parse_args()
    run=args.run;report={}
    final=run/'run-summary.json'
    if final.exists():
        data=json.loads(final.read_text())
        report={key:data.get(key) for key in ['status','requested_samples','successful_stage_seconds','successful_stage_sum_seconds']}
    else:
        status=run/'run-status.json'
        if status.exists():report['status_record']=json.loads(status.read_text())
        report['completed_sequence_chunks']=len(list((run/'segments').glob('*/record.json')))
        for phase,pattern in [('sequence','segments/*/attempt-*.log'),('generator','generator/attempt-*.log'),
                              ('reconstruction','reconstruction/attempt-*.log'),('verification','verification/attempt-*.log')]:
            paths=sorted(run.glob(pattern),key=lambda p:p.stat().st_mtime)
            if paths:
                report['phase']=phase;report['progress']=last_json(paths[-1]);report['log']=str(paths[-1])
    print(json.dumps(report))


if __name__=='__main__':main()
