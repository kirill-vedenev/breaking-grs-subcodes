#!/usr/bin/env python3
"""Check branch separation and continuation from this run's verified sample.

Run with SageMath, on the server or locally after restoring the core results.
Failure is recorded separately from successful holdout-polynomial verification.
"""
import argparse
import json
from pathlib import Path
import shutil
import sys

from validate_inputs import validate
from server import ROOT, attempt, check_verification, execute, restore, seal, sha, write


def main():
    from sage.all import version
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path, default=ROOT / 'runs/roots312')
    parser.add_argument('--inputs', type=Path, default=ROOT / 'inputs')
    args = parser.parse_args()
    run, inputs = args.run.resolve(), args.inputs.resolve()
    construction = validate(inputs)
    config = json.loads((inputs / 'experiment.json').read_text())
    identity = json.loads((run / 'identity.json').read_text())
    for name in ['public.json', 'operator.txt', 'request.txt', 'experiment.json', 'vanishing-record.json']:
        if identity['input_hashes'][name] != sha(inputs / name):
            raise ValueError('run belongs to different inputs: ' + name)
    verification = restore(run / 'verification')
    if verification is None:
        raise ValueError('verified holdout polynomials are required')
    check_verification(json.loads(verification['verification'].read_text()), config, production=True)
    # Inspection keeps the tensor hashes even when the redundant panel/map
    # have not been restored from the result archive.
    inspection_record = json.loads((run / 'inspection/record.json').read_text())
    artifacts = inspection_record['artifacts']
    source = {}
    for name in ['report', 'hasse_0', 'hasse_1', 'hasse_2']:
        item = artifacts[name]
        path = (run / 'inspection' / item['path']).resolve()
        if not path.is_relative_to((run / 'inspection').resolve()):
            raise ValueError('inspection artifact escapes its directory')
        if path.stat().st_size != item['bytes'] or sha(path) != item['sha256']:
            raise ValueError('inspection artifact changed: ' + name)
        source[name] = path
    inspection = json.loads(source['report'].read_text())
    if inspection['instance_id'] != config['instance_id']:
        raise ValueError('inspection belongs to a different profile')
    job = run / 'standard-checks'
    ready = restore(job)
    if ready is None:
        dest = attempt(job); dest.mkdir()
        for order in range(3):
            shutil.copy2(source[f'hasse_{order}'], dest / f'hasse-{order}.u64le')
        index = dict(count=config['requested_samples'], public_sha256=config['original_public_sha256'])
        write(dest / 'sample-index.json', index)
        error = None
        try:
            execute([sys.executable, ROOT / 'recovery/check_criterion.py', inputs / 'public.json',
                     dest / 'sample-index.json', dest], dest / 'criterion.log')
        except Exception as exc:
            error = str(exc)
        criterion_path = dest / 'criterion.json'
        criterion = json.loads(criterion_path.read_text()) if criterion_path.exists() else {}
        passed = (error is None and criterion.get('binary_rank_criterion_holds')
                  and criterion.get('one_full_frobenius_orbit')
                  and criterion.get('all_binary_continuation_checks_pass'))
        expected_failure = error is not None and criterion.get('binary_rank_criterion_holds') is False
        status = 'passed' if passed else 'criterion_failed' if criterion and (expected_failure or 'all_binary_continuation_checks_pass' in criterion) else 'execution_failed'
        report = dict(status=status, instance_id=config['instance_id'], public_only=True,
                      prior_recovered_key_or_jet_used=False, sage=str(version()),
                      kernel_sha256=inspection['kernel_sha256'],
                      gradient_rank=criterion.get('gradient_rank'),
                      quadratic_rank=criterion.get('restricted_quadratic_rank'),
                      branch_separation_checked=bool(criterion.get('branches')),
                      continuation_checks=criterion.get('continuation_checks', []),
                      all_binary_continuation_checks_pass=bool(criterion.get('all_binary_continuation_checks_pass')),
                      curve_vanishing_certified_by_pinned_preparation=construction["curve_vanishing_certified"],
                      full_key_recovery_completed=False, error=error)
        write(dest / 'standard-checks.json', report)
        saved = dict(report=dest / 'standard-checks.json', log=dest / 'criterion.log')
        if criterion_path.exists():
            saved['criterion'] = criterion_path
        # Software execution failures stay retryable. Mathematical outcomes
        # are sealed and never turned into a new seed or a filtered sample.
        if status != 'execution_failed':
            ready = seal(job, saved)
        else:
            print(json.dumps(report), flush=True)
            raise RuntimeError('standard checks could not execute; diagnostics retained')
    report = json.loads(ready['report'].read_text())
    print(json.dumps(report), flush=True)
    if report['status'] != 'passed':
        raise SystemExit(2)


if __name__ == '__main__':
    main()
