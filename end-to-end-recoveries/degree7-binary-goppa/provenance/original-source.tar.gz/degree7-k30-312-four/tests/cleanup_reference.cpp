#include "../holdout/src/residual_cleanup.hpp"
#include <fstream>
#include <iostream>
#include <string>
int main(int argc,char** argv) {try {
    if(argc!=4)throw std::runtime_error("usage: cleanup-reference words residual.bin transform.bin");
    int words=std::stoi(argv[1]);std::ifstream input(argv[2],std::ios::binary|std::ios::ate);
    if(!input)throw std::runtime_error("cannot read residual");
    auto bytes=input.tellg();input.seekg(0);
    if(bytes<0 || bytes%8)throw std::runtime_error("bad residual length");
    std::vector<std::uint64_t> data(std::size_t(bytes)/8);
    input.read(reinterpret_cast<char*>(data.data()),bytes);
    if(!input)throw std::runtime_error("short residual read");
    auto result=residual_cleanup::kernel_transform(data,words);
    std::ofstream output(argv[3],std::ios::binary);
    output.write(reinterpret_cast<const char*>(result.transform.data()),result.transform.size()*8);
    if(!output)throw std::runtime_error("transform write failed");
    std::cout<<"{\"residual_rank\":"<<result.residual_rank<<",\"retained_columns\":"<<result.retained_columns<<"}\n";
    return 0;
} catch(const std::exception& error) {std::cerr<<error.what()<<'\n';return 1;}}
