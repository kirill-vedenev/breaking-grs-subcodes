"""Verify per-trial core archives and honest handling of an unsealed failure."""
from pathlib import Path
import contextlib,hashlib,io,json,shutil,sys,tarfile,tempfile
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
import collect_results
from server import seal


def main():
    original_root,original_argv=collect_results.ROOT,sys.argv
    with tempfile.TemporaryDirectory(prefix='four-collect-test-') as temporary:
        temp=Path(temporary).resolve();inputs=temp/'trials/fixture/inputs';inputs.mkdir(parents=True)
        run=temp/'trials/fixture/run';run.mkdir()
        fixture=ROOT/'validation/cpu-mixed'
        cert=json.loads((fixture/'verification.json').read_text())
        config=dict(trial_id='fixture',seed=123,instance_id=cert['instance_id'],requested_samples=16,forced_zeros=0,solver='test')
        (inputs/'experiment.json').write_text(json.dumps(config))
        for name in ['SOURCE-PROVENANCE.json','PLAN.json','TRIALS.json']:(temp/name).write_text('{}\n')
        reconstruction=run/'reconstruction';reconstruction.mkdir()
        shutil.copy2(fixture/'kernel-colex.bin',reconstruction/'kernel.thk1')
        seal(reconstruction,{'kernel':reconstruction/'kernel.thk1'})
        verification=run/'verification';verification.mkdir()
        (verification/'attempt-1').mkdir();path=verification/'attempt-1/verification.json'
        path.write_text(json.dumps(cert));seal(verification,{'verification':path})
        seq=run/'sequence';seq.mkdir();(seq/'sequence.raw.bin').write_bytes(b'not required')
        collect_results.ROOT=temp
        try:
            outcomes=[]
            for wanted in ['kernel_verified','verification_failed']:
                if wanted=='verification_failed':
                    (verification/'record.json').unlink()
                    path.write_text(json.dumps(dict(cert,heldout_nonzero_values=1)))
                sys.argv=['collect_results.py','--run',str(run),'--inputs',str(inputs)]
                with contextlib.redirect_stdout(io.StringIO()):collect_results.main()
                manifest=json.loads((temp/'artifacts/fixture-download-manifest.json').read_text())
                assert manifest['status']==wanted and len(manifest['archives'])==1 and not manifest['replay_included']
                item=manifest['archives'][0];archive=temp/item['path']
                assert hashlib.sha256(archive.read_bytes()).hexdigest()==item['sha256']
                with tarfile.open(archive) as tar:
                    names=tar.getnames()
                    assert 'trials/fixture/run/reconstruction/kernel.thk1' in names
                    assert 'trials/fixture/run/sequence/sequence.raw.bin' not in names
                    inventory=json.load(tar.extractfile(next(n for n in names if n.endswith('.inventory.json'))))
                    for name,record in inventory['files'].items():
                        raw=tar.extractfile(name).read()
                        assert len(raw)==record['bytes'] and hashlib.sha256(raw).hexdigest()==record['sha256']
                outcomes.append(wanted)
        finally:collect_results.ROOT=original_root;sys.argv=original_argv
    report=dict(status='passed',cases=outcomes,core_only=True,failed_trial_not_promoted=True)
    (ROOT/'validation/collection-tests.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))


if __name__=='__main__':main()
