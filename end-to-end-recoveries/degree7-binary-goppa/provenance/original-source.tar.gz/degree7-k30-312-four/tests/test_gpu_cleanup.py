#!/usr/bin/env python3
"""Inject one bad candidate direction and verify exact GPU residual cleanup."""
from pathlib import Path
import argparse
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from server import restore,execute,write


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--run',type=Path,default=ROOT/'runs/gpu-smoke')
    ap.add_argument('--output',type=Path,default=ROOT/'runs/gpu-cleanup-fault-injection')
    args=ap.parse_args();out=args.output.resolve()
    if out.exists():raise FileExistsError('fault-injection output exists')
    original=restore(args.run.resolve()/'generator')['generator']
    baseline=restore(args.run.resolve()/'reconstruction')['result']
    baseline_rank=json.loads(baseline.read_text())['residual_rank_removed']
    out.mkdir(parents=True)
    data=bytearray(original.read_bytes());data[0]^=1
    generator=out/'perturbed.gen';generator.write_bytes(data)
    cfg=json.loads((ROOT/'tests/smoke-inputs/experiment.json').read_text())
    dest=out/'reconstruction'
    execute([ROOT/'holdout/build/square-worker','recover',ROOT/'tests/smoke-inputs/request.txt',
             generator,dest,1,cfg['solver_seed'],cfg['compressor_seed'],1,16],out/'reconstruction.log',gpu=True)
    result=json.loads((dest/'recovery-result.json').read_text())
    assert result['raw_residual_nonzero']
    assert max(0,baseline_rank-1)<=result['residual_rank_removed']<=baseline_rank+1
    assert result['exact_kernel'] and result['independent_rank']==16
    execute([ROOT/'holdout/build/holdout-cpu','verify',ROOT/'tests/smoke-inputs/operator.txt',
             dest/'kernel.thk1',out/'independent-verification.json','--threads',2],out/'verification.log')
    report=dict(status='passed',scope='Deliberate corruption of a copied smoke generator; production files unchanged',
                one_coefficient_bit_flipped=True,baseline_residual_rank=baseline_rank,
                raw_residual_rank=result['residual_rank_removed'],GPU_cleanup_exercised=True,
                accepted_independent_vectors=16,all_original_orders_verified=True)
    write(out/'summary.json',report);print(json.dumps(report),flush=True)


if __name__=='__main__':main()
