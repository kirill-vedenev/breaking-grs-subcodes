#!/usr/bin/env python3
"""Small degree-seven fixture exercising both multiplicities 5 and 6."""
import hashlib
import json
from math import comb
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from algebra import retained_orders

out=ROOT/'tests/mixed-smoke-inputs';out.mkdir(exist_ok=True)
k=15;d=7;points=[(255,6),(32640,5),(21845,5)]
N=comb(k,d);J=sum(comb(k,u) for _,s in points for u in retained_orders(d,s))
nonzeros=sum(comb(p.bit_count(),d-u)*comb(k-d+u,u) for p,s in points for u in retained_orders(d,s))
identity=hashlib.sha256(b'degree7-k30-mixed-smoke-k15-6-5-5').hexdigest()
op=['TII_HOLDOUT_V1',f'instance_id {identity}',f'k {k}',f'degree {d}',
    'minimum 16','heldout_original 99','heldout_mask 32767',f'points {len(points)}']
op += [f'{i} {p} {s}' for i,(p,s) in enumerate(points)]
req=['mceliecex-holdout-cuda-request-v1',f'public_sha256 {identity}',f'k {k}',f'degree {d}',
     'words 8','repetitions 1','seed 2026101615','emit_output 0',f'expected_columns {N}',
     f'expected_rows {J}',f'expected_nonzeros {nonzeros}',f'point_count {len(points)}']
for p,s in points:
    levels=retained_orders(d,s);req.append(f'point {p} {len(levels)} '+' '.join(map(str,levels)))
cfg=dict(schema='degree7-mixed-smoke-v1',N=N,J=J,nonzeros=nonzeros,block_bits=512,requested_samples=16,
         sequence_terms=2*((N+511)//512)+256,solver_seed=2026101615,compressor_seed=2026101616,
         fft_batch_words=2,scope='Software check of mixed multiplicities, not a Goppa recovery')
for name,content in [('operator.txt','\n'.join(op)+'\n'),('request.txt','\n'.join(req)+'\n'),
                     ('experiment.json',json.dumps(cfg,indent=2)+'\n')]:
    path=out/name
    if path.exists() and path.read_text()!=content:raise ValueError('existing fixture differs')
    path.write_text(content)
print(json.dumps(cfg))
