"""Check cohort integrity, structural profile, native dimensions, and corruption rejection."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from algebra import rref, restrict, columns
from validate_inputs import validate
from server import establish, seal, restore


def reject(action):
    try: action()
    except (ValueError,AssertionError,FileNotFoundError): return
    raise AssertionError('corrupt input accepted')


def main():
    registry=json.loads((ROOT/'TRIALS.json').read_text())
    assert len(registry['trials'])==4 and all(t['status']=='prepared' for t in registry['trials'])
    assert len({t['original_public_sha256'] for t in registry['trials']})==4
    results=[];failures=0
    for trial in registry['trials']:
        inputs=ROOT/trial['inputs'];validate(inputs)
        public=json.loads((inputs/'public.json').read_text());original=json.loads((inputs/'original-public.json').read_text())
        config=json.loads((inputs/'experiment.json').read_text())
        mask=lambda row:sum(int(x)<<i for i,x in enumerate(row))
        P=list(map(mask,public['generator']));G=list(map(mask,original['generator']));H=list(map(mask,original['parity_check']))
        assert len(rref(P,54)[0])==30 and len(rref(G,64)[0])==40 and len(rref(H,64)[0])==24
        assert all(not ((a&b).bit_count()&1) for a in G for b in H)
        Hs=[restrict(row,public['original_indices']) for row in H]
        assert len(rref(Hs,54)[0])==24 and all(not ((a&b).bit_count()&1) for a in P for b in Hs)
        points=columns(P,54);held=public['heldout'][0]
        assert public['heldout_mask']==points[held]
        assert [points[j] for j in public['information_set']]==[1<<j for j in range(30)]
        expected=[i for i in range(54) if i!=held and i not in public['information_set']][:12]
        assert [i for i,s in enumerate(public['multiplicities']) if s==5]==expected
        assert sum(public['multiplicities'])+public['infinity_multiplicity']==312
        assert public['infinity_multiplicity']==6 and public['multiplicities'][held]==0
        assert config['solver_seed']==2026101602 and config['compressor_seed']==2026101603
        assert config['requested_samples']==256 and config['sequence_terms']==8210
        active=[p for p in public['points'] if p['mask'].bit_count()>1]
        assert min(p['mask'].bit_count() for p in active)>=7
        native=json.loads(subprocess.check_output([ROOT/'holdout/build/holdout-cpu','inspect',inputs/'operator.txt'],text=True))
        assert native['rows']==config['J']==2136372 and native['columns']==2035800
        with tempfile.TemporaryDirectory(prefix='four-trial-validation-') as temp:
            copied=Path(temp)/'inputs';shutil.copytree(inputs,copied)
            for name in trial['input_sha256']:
                path=copied/name;raw=path.read_bytes();path.write_bytes(raw+b' ')
                reject(lambda:validate(copied));failures+=1;path.write_bytes(raw)
            run=Path(temp)/'run';establish(run,copied,config,1024,False);establish(run,copied,config,1024,True)
            reject(lambda:establish(run,copied,dict(config,solver_seed=1),1024,True));failures+=1
            reject(lambda:establish(run,copied,config,512,True));failures+=1
            job=Path(temp)/'stage';job.mkdir();data=job/'data';data.write_bytes(b'abc');seal(job,{'data':data})
            data.write_bytes(b'abd');reject(lambda:restore(job));failures+=1
        results.append(dict(trial_id=trial['trial_id'],key_seed=trial['key_seed'],input_check='passed',
                            curve_vanishing_certified=trial['curve_vanishing_certified'],
                            minimum_explicit_point_weight=min(p['mask'].bit_count() for p in active),
                            native_rows=native['rows'],native_columns=native['columns']))
    report=dict(status='passed',trials=results,corruption_cases_rejected=failures,
                distinct_original_public_keys=4,no_private_key_read=True,no_seeds_replaced=True)
    path=ROOT/'validation/batch-input-tests.json';path.parent.mkdir(exist_ok=True)
    path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)


if __name__=='__main__': main()
