#!/usr/bin/env python3
"""Prepare a smoke matrix with enough nullity for the 512-column generator."""
from pathlib import Path
from math import comb
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1];out=ROOT/'tests/wide-smoke-inputs';out.mkdir(exist_ok=True)
k,d,b=15,7,512;points=[255,32640]
N=comb(k,d);J=len(points)*(comb(k,3)+comb(k,5))
nnz=sum(comb(p.bit_count(),2)*comb(k-2,5)+comb(p.bit_count(),4)*comb(k-4,3) for p in points)
identity=hashlib.sha256(b'degree7-k30-wide-smoke-k15-two-weight8-points').hexdigest()
op=['TII_HOLDOUT_V1',f'instance_id {identity}',f'k {k}',f'degree {d}','minimum 16',
    'heldout_original 99','heldout_mask 32767',f'points {len(points)}']
op += [f'{j} {p} 6' for j,p in enumerate(points)]
req=['mceliecex-holdout-cuda-request-v1',f'public_sha256 {identity}',f'k {k}',f'degree {d}',
     'words 8','repetitions 1','seed 2026101615','emit_output 0',f'expected_columns {N}',
     f'expected_rows {J}',f'expected_nonzeros {nnz}',f'point_count {len(points)}']
req += [f'point {p} 2 3 5' for p in points]
cfg=dict(schema='degree7-wide-smoke-v2',N=N,J=J,nonzeros=nnz,block_bits=b,requested_samples=16,
         sequence_terms=2*((N+b-1)//b)+256,solver_seed=2026101615,compressor_seed=2026101616,
         fft_batch_words=2,scope='Derivative matrix with production-width 512-bit blocks; not a Goppa recovery')
for name,content in [('operator.txt','\n'.join(op)+'\n'),('request.txt','\n'.join(req)+'\n'),
                     ('experiment.json',json.dumps(cfg,indent=2)+'\n')]:
    path=out/name
    if path.exists() and path.read_text()!=content:raise ValueError('existing fixture differs')
    path.write_text(content)
print(json.dumps(cfg))
