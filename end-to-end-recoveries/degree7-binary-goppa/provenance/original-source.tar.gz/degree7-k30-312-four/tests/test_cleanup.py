"""Compare the production packed residual cleanup with exact Sage nullspaces."""
from sage.all import GF, matrix, random_matrix, set_random_seed
from pathlib import Path
import argparse
import json
import struct
import subprocess

ROOT=Path(__file__).resolve().parents[1]


def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--output',type=Path,required=True)
    args=ap.parse_args()
    if args.output.exists():raise FileExistsError('test output exists')
    args.output.mkdir(parents=True)
    set_random_seed(2026101614);cases=[]
    for words in (1,2,8,16):
        b=64*words
        for wanted in (0,1,13,b):
            if wanted==0:B=matrix(GF(2),17,b)
            elif wanted==b:B=matrix.identity(GF(2),b)
            else:
                right=random_matrix(GF(2),wanted,b)
                while right.rank()!=wanted:right=random_matrix(GF(2),wanted,b)
                left=matrix.identity(GF(2),wanted).stack(random_matrix(GF(2),37,wanted))
                B=left*right
            raw=b''.join(sum(int(x)<<i for i,x in enumerate(row)).to_bytes(words*8,'little') for row in B.rows())
            stem=args.output/f'w{words}-r{wanted}'
            source=stem.with_suffix('.input');target=stem.with_suffix('.output');source.write_bytes(raw)
            result=subprocess.run([str(ROOT/'build/cleanup-reference'),str(words),str(source),str(target)],
                                  check=True,capture_output=True,text=True)
            report=json.loads(result.stdout)
            values=struct.unpack('<'+'Q'*(b*words),target.read_bytes())
            C=matrix(GF(2),b,b,lambda i,j:(values[i*words+j//64]>>(j%64))&1)
            assert report['residual_rank']==wanted and report['retained_columns']==b-wanted
            assert not B*C and C.rank()==b-wanted and C.column_space()==B.right_kernel()
            assert not C.matrix_from_columns(range(b-wanted,b))
            cases.append(dict(words=words,residual_rank=wanted,nullity=b-wanted))
    summary=dict(status='passed',cases=cases,production_cpp_used=True,
                 oracle='Sage GF(2) right kernels',GPU_executed=False)
    (args.output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))


if __name__=='__main__':main()
