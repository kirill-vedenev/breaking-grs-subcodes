#!/usr/bin/env python3
"""Small public degree-seven operator, shared by CPU and GPU smoke tests."""
import hashlib
import json
from math import comb
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
out=ROOT/'tests/smoke-inputs';out.mkdir(exist_ok=True)
k,d,point=12,7,(1<<8)-1
N=comb(k,d);J=comb(k,3)+comb(k,5)
nnz=comb(8,2)*comb(10,5)+comb(8,4)*comb(8,3)
identity=hashlib.sha256(b'degree7-k30-operator-smoke-v3-weight8').hexdigest()
op=['TII_HOLDOUT_V1',f'instance_id {identity}',f'k {k}',f'degree {d}',
    'minimum 16','heldout_original 99','heldout_mask 2047','points 1',f'0 {point} 6']
req=['mceliecex-holdout-cuda-request-v1',f'public_sha256 {identity}',f'k {k}',f'degree {d}',
     'words 1','repetitions 1','seed 2026101612','emit_output 0',f'expected_columns {N}',
     f'expected_rows {J}',f'expected_nonzeros {nnz}','point_count 1',f'point {point} 2 3 5']
config=dict(schema='degree7-operator-smoke-v1',N=N,J=J,nonzeros=nnz,block_bits=64,
            requested_samples=16,sequence_terms=2*((N+63)//64)+256,
            solver_seed=2026101612,compressor_seed=2026101613,fft_batch_words=1,
            scope='Synthetic binary derivative operator, not a Goppa key-recovery experiment')
for name,data in [('operator.txt','\n'.join(op)+'\n'),('request.txt','\n'.join(req)+'\n'),
                  ('experiment.json',json.dumps(config,indent=2)+'\n')]:
    path=out/name
    if path.exists() and path.read_text()!=data:raise ValueError('smoke fixture changed')
    path.write_text(data)
print(json.dumps(config))
